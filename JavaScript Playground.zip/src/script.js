const message = 'Hello world' // Try edit me

// Update header text
document.querySelector('#header').innerHTML = message

// Log to console
console.log(message)

var items = ["apple","mango","banana"];
 
items.push();
 
console.log(items);

var lists = ['apple', 'mango', 'banana'];
 
for (  var i = 0;  i < lists.length;  i++  ) {
 
 console.log ( lists[ i ] );
 
}